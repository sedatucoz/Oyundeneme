package com.example.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.viewmodel.*
import kotlinx.coroutines.delay

// --- Main Menu Screen ---
@Composable
fun MainMenuScreen(
    state: GameState,
    onStartGame: () -> Unit,
    onOpenShop: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF0F1E19), Color(0xFF050805))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        // Ambient Background Canvas Decorations (Simulated swamp reeds & water)
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawSwampBorders()
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .padding(24.dp)
                .widthIn(max = 450.dp)
        ) {
            // Logo / Title Bubble
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .padding(bottom = 8.dp)
                    .size(100.dp)
                    .background(Color(0x1A2E7D32), CircleShape)
            ) {
                // Floating Soft Cute Monster Logo Symbol
                Canvas(modifier = Modifier.size(70.dp)) {
                    drawMenuLogoGhost()
                }
            }

            Text(
                text = "JUMBO CLAY",
                fontSize = 32.sp,
                fontWeight = FontWeight.Black,
                color = Color(0xFF81C784),
                letterSpacing = 1.5.sp,
                textAlign = TextAlign.Center,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(bottom = 4.dp)
            )
            
            Text(
                text = "Kil Hayaletleri",
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium,
                color = Color(0xFF4CAF50).copy(alpha = 0.8f),
                fontFamily = FontFamily.SansSerif,
                modifier = Modifier.padding(bottom = 32.dp)
            )

            // High Score Banner
            Surface(
                color = Color(0x332E7D32),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF4CAF50).copy(alpha = 0.5f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 40.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Favorite serves as star in standard core icons
                        Icon(
                            imageVector = Icons.Default.Favorite,
                            contentDescription = "Personal Best",
                            tint = Color(0xFFFFD700),
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "HIGH SCORE",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFC8E6C9),
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Text(
                        text = state.highscore.toString(),
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Black,
                        color = Color(0xFFFFD700),
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // Play & Shop Action Buttons
            Button(
                onClick = onStartGame,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF4CAF50),
                    contentColor = Color(0xFF0D3111)
                ),
                shape = RoundedCornerShape(14.dp),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 6.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .padding(bottom = 12.dp)
                    .testTag("play_button")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Oyna / Play",
                        tint = Color(0xFF0F1E19),
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "START RAID (OYNA)",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            OutlinedButton(
                onClick = onOpenShop,
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = Color(0xFF81C784)
                ),
                border = androidx.compose.foundation.BorderStroke(2.dp, Color(0xFF4CAF50)),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .testTag("shop_button")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.ShoppingCart,
                        contentDescription = "Butik / Shop",
                        tint = Color(0xFF81C784),
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "GHOST SHOP (BUTİK)",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            
            // Swamp Essences Balance Banner using info icon
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = "Swamp points",
                    tint = Color(0xFF80DEEA),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "${state.swampPoints} Öz / Essences",
                    fontSize = 13.sp,
                    color = Color(0xFF80DEEA),
                    fontWeight = FontWeight.Medium,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

// --- Shop / skins Screen ---
@Composable
fun ShopScreen(
    state: GameState,
    onBack: () -> Unit,
    onSelectSkin: (String) -> Unit,
    onPurchaseSkin: (GhostSkin) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF070B08))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
        ) {
            // Header Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp, bottom = 20.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .background(Color(0x3381C784), CircleShape)
                        .testTag("shop_back_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Geri / Back",
                        tint = Color(0xFF81C784)
                    )
                }

                Text(
                    text = "GHOST BOUTIQUE",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    color = Color(0xFF81C784),
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.align(Alignment.CenterVertically)
                )

                // Points status Box
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0x3300E676))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Favorite,
                            contentDescription = "Tokens",
                            tint = Color(0xFF00E676),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = state.swampPoints.toString(),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black,
                            color = Color(0xFF00E676),
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            Text(
                text = "Unutulmuş bataklık özleriyle hayaletlerinin görünümlerini değiştir!",
                fontSize = 12.sp,
                color = Color.Gray,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
            )

            // Grid displaying Skins
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(GhostSkin.ALL_SKINS) { skin ->
                    val isUnlocked = state.unlockedSkins.contains(skin.id)
                    val isSelected = state.activeSkinId == skin.id

                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) Color(0x334CAF50) else Color(0xFF121815)
                        ),
                        border = androidx.compose.foundation.BorderStroke(
                            width = if (isSelected) 2.dp else 1.dp,
                            color = if (isSelected) Color(0xFF4CAF50) else Color(0x3381C784)
                        ),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(0.8f)
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(12.dp)
                        ) {
                            // Render Preview of custom ghost skin
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(75.dp)
                                    .padding(top = 8.dp)
                            ) {
                                Canvas(modifier = Modifier.fillMaxSize()) {
                                    drawCustomSkinGhost(skin)
                                }
                            }

                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = skin.name,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontFamily = FontFamily.Monospace,
                                    textAlign = TextAlign.Center
                                )
                                Text(
                                    text = skin.label,
                                    fontSize = 10.sp,
                                    color = Color.Gray,
                                    fontFamily = FontFamily.SansSerif,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(top = 2.dp)
                                )
                            }

                            // Dynamic action buttons
                            when {
                                isSelected -> {
                                    Button(
                                        onClick = {},
                                        enabled = false,
                                        colors = ButtonDefaults.buttonColors(
                                            disabledContainerColor = Color(0xFF1B5E20),
                                            disabledContentColor = Color(0xFF81C784)
                                        ),
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(36.dp)
                                    ) {
                                        Text("SELECTED", fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                    }
                                }
                                isUnlocked -> {
                                    Button(
                                        onClick = { onSelectSkin(skin.id) },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = Color(0xFF2E7D32),
                                            contentColor = Color.White
                                        ),
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(36.dp)
                                    ) {
                                        Text("SELECT", fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                    }
                                }
                                else -> {
                                    Button(
                                        onClick = { onPurchaseSkin(skin) },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = Color(0xFF00796B),
                                            contentColor = Color.White
                                        ),
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(36.dp)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Favorite,
                                                contentDescription = "Cost",
                                                tint = Color(0xFFFFD700),
                                                modifier = Modifier.size(10.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(skin.cost.toString(), fontSize = 11.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- Active Play Screen ---
@Composable
fun PlayingScreen(
    state: GameState,
    activeGhosts: List<Ghost>,
    activeBubbles: List<MudBubble>,
    activeParticles: List<SplashParticle>,
    activeClouds: List<FogCloud>,
    activeRipples: List<GroundRipple>,
    onGestureTap: (Float, Float, Float, Float) -> Unit,
    onRestart: () -> Unit,
    onMenu: () -> Unit,
    onWatchDouble: () -> Unit,
    onWatchRevive: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF0E1A16), Color(0xFF040604))
                )
            )
    ) {
        // Core Interactive Physics/Gaming Canvas board
        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures(
                        onTap = { offset ->
                            onGestureTap(
                                size.width.toFloat(),
                                size.height.toFloat(),
                                offset.x,
                                offset.y
                            )
                        }
                    )
                }
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                // Background elements
                drawSwampBorders(activeGhosts, activeRipples)

                // Render Swamp rising mud bubbles
                activeBubbles.forEach { bubble ->
                    drawMudBubbleElement(bubble)
                }

                // Render Ghosts (Custom Vector paths with squishy bounce)
                activeGhosts.forEach { ghost ->
                    drawGhostEntity(ghost, state.activeSkinId)
                }

                // Render Slash/Debris particles
                activeParticles.forEach { particle ->
                    drawParticleElement(particle)
                }

                // Render top atmospheric floating fog
                activeClouds.forEach { cloud ->
                    drawFogElement(cloud)
                }
            }
        }

        // HUD Heads Up Display Overlays
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 44.dp, start = 20.dp, end = 20.dp)
        ) {
            // First Top Row: Health, Combo, Score
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Heart Lifes Counter
                Row {
                    for (i in 1..3) {
                        val active = i <= state.lives
                        Icon(
                            imageVector = if (active) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Hearts",
                            tint = if (active) Color(0xFFFF1744) else Color(0xFF424242).copy(alpha = 0.5f),
                            modifier = Modifier
                                .size(28.dp)
                                .padding(end = 4.dp)
                        )
                    }
                }

                // Cumulative Live score
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "SCORE",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF81C784),
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = state.score.toString(),
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // Combo Gauge indicator
            if (state.comboCount > 0) {
                Row(
                    modifier = Modifier
                        .padding(top = 12.dp)
                        .align(Alignment.CenterHorizontally),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "x${state.comboMultiplier}",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Black,
                        color = when (state.comboMultiplier) {
                            5 -> Color(0xFFFFB300)
                            3 -> Color(0xFFE040FB)
                            2 -> Color(0xFF00E5FF)
                            else -> Color(0xFF00E676)
                        },
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(end = 8.dp)
                    )

                    Column(modifier = Modifier.width(100.dp)) {
                        Text(
                            text = "COMBO ${state.comboCount}",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.LightGray,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(bottom = 2.dp)
                        )
                        // Progress bar reflecting timing depletion
                        LinearProgressIndicator(
                            progress = { state.comboGauge },
                            color = Color(0xFF00E676),
                            trackColor = Color(0xFF263238),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp))
                        )
                    }
                }
            }
        }

        // Game Over Panel Trigger Box
        if (state.isGameOver) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xE6050A05)),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier
                        .padding(28.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(Color(0xFF0D140F))
                        .border(
                            androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2E7D32)),
                            shape = RoundedCornerShape(24.dp)
                        )
                        .padding(24.dp)
                        .widthIn(max = 400.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Game Over Symbol",
                        tint = Color(0xFFFF1744),
                        modifier = Modifier
                            .size(56.dp)
                            .padding(bottom = 8.dp)
                    )

                    Text(
                        text = "DEFEAT",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black,
                        color = Color(0xFFFF1744),
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.2.sp
                    )
                    
                    Text(
                        text = "3 hayalet kaçtı ve bataklığından oldun!",
                        fontSize = 11.sp,
                        color = Color.Gray,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(bottom = 20.dp)
                    )

                    Surface(
                        color = Color(0x1F2E7D32),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "OBTAINED SCORE",
                                fontSize = 10.sp,
                                color = Color.Gray,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = state.score.toString(),
                                fontSize = 34.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontFamily = FontFamily.Monospace
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = "SWAMP BEST",
                                fontSize = 10.sp,
                                color = Color.Gray,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = state.highscore.toString(),
                                fontSize = 18.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFFFFD700),
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    // Monetization Option A: Double score standard ad
                    Button(
                        onClick = onWatchDouble,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF00796B),
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                            .testTag("double_score_button")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.PlayArrow, contentDescription = "Ad", tint = Color(0xFFFFB300))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("WATCH AD: DOUBLE SCORE (2x Skor)", fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    }

                    // Monetization Option B: Revive standard ad
                    Button(
                        onClick = onWatchRevive,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFC2185B),
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp)
                            .testTag("revive_button")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Refresh, contentDescription = "Revive", tint = Color.White)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("WATCH AD: REVIVE (Canlan)", fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    }

                    Divider(color = Color(0x332E7D32), modifier = Modifier.padding(bottom = 16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(
                            onClick = onMenu,
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x3381C784)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("menu_button")
                        ) {
                            Text("MENU", fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }

                        Button(
                            onClick = onRestart,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF388E3C)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("restart_button")
                        ) {
                            Text("RETRY", fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }
    }
}

// --- Advertising Simulation Screen Pane ---
@Composable
fun SimulatedAdDisplay(
    adState: AdState,
    countdown: Int,
    onSkip: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(32.dp)
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(80.dp)
                    .background(Color(0xFF263238), CircleShape)
                    .padding(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Simulated Advertisement",
                    tint = Color(0xFF00E676),
                    modifier = Modifier.size(46.dp)
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "SPONSOR ADVERTISEMENT",
                fontSize = 13.sp,
                color = Color.Gray,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )

            Text(
                text = when (adState) {
                    AdState.SHOWING_INTERSTITIAL -> "Önemli Geçiş Reklamı (Interstitial)"
                    AdState.SHOWING_REWARDED_DOUBLE -> "rewarded Ad: Score 2x Bonus!"
                    else -> "rewarded Ad: Revive Lifeforce!"
                },
                fontSize = 16.sp,
                color = Color.White,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.SansSerif,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 4.dp, bottom = 24.dp)
            )

            // Animated fake video loop box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF10201A)),
                contentAlignment = Alignment.Center
            ) {
                val infiniteTransition = rememberInfiniteTransition(label = "pulse")
                val pulseColor by infiniteTransition.animateColor(
                    initialValue = Color(0xFF00796B),
                    targetValue = Color(0xFF004D40),
                    animationSpec = infiniteRepeatable(
                        animation = tween(1200, easing = LinearEasing),
                        repeatMode = RepeatMode.Reverse
                    ), label = "ad"
                )
                
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier
                        .fillMaxSize()
                        .background(pulseColor)
                ) {
                    Text(
                        text = "Cute Slimes Video Ad Playback",
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "www.google_aistudio_simulated_network.io",
                        color = Color.White.copy(alpha = 0.5f),
                        fontSize = 10.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // Timer ticker circular
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(70.dp)
            ) {
                CircularProgressIndicator(
                    progress = { countdown / 5.0f },
                    color = Color(0xFFFFD700),
                    strokeWidth = 5.dp,
                    trackColor = Color(0xFF263238),
                    modifier = Modifier.fillMaxSize()
                )
                Text(
                    text = countdown.toString(),
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace
                )
            }

            Text(
                text = "Reklam $countdown saniye sonra atlanabilir.",
                fontSize = 11.sp,
                color = Color.Gray,
                modifier = Modifier.padding(top = 16.dp)
            )
        }
    }
}


// ==========================================
// --- Vector Canvas Drawing Subsystems ---
// ==========================================

fun DrawScope.drawSwampBorders(
    activeGhosts: List<Ghost> = emptyList(),
    activeRipples: List<GroundRipple> = emptyList()
) {
    val w = size.width
    val h = size.height
    
    val edgePath = Path()
    edgePath.moveTo(0f, h)
    
    val segments = 60
    for (i in 0..segments) {
        val xFraction = i.toFloat() / segments
        val xPx = xFraction * w
        
        var baseMudY = h - (45f + 15f * Math.sin((xFraction * 2f * Math.PI) + 0.6).toFloat())
        
        // 1. Elastic stretching pull for emerging ghosts
        activeGhosts.forEach { ghost ->
            if (!ghost.hasExitedMud && ghost.y >= 0.82f && ghost.y <= 1.12f) {
                val deltaX = Math.abs(xFraction - ghost.x)
                if (deltaX < 0.12f) {
                    val decay = Math.exp(-((deltaX / 0.05f) * (deltaX / 0.05f)).toDouble()).toFloat()
                    val pullHeight = (1.06f - ghost.y).coerceIn(0f, 0.22f) * h * 0.7f
                    baseMudY -= pullHeight * decay
                }
            }
        }
        
        // 2. Wave/ripple offset for snapped drops
        activeRipples.forEach { r ->
            val deltaX = Math.abs(xFraction - r.x)
            if (deltaX < 0.22f) {
                val distanceRatio = deltaX / 0.22f
                val decay = Math.exp(-((deltaX / 0.08f) * (deltaX / 0.08f)).toDouble()).toFloat() * (1f - r.age)
                val frequencyRad = 15f
                val waveOffset = 30f * decay * Math.sin((r.age * frequencyRad - distanceRatio * 8f).toDouble()).toFloat()
                baseMudY -= waveOffset
            }
        }
        
        edgePath.lineTo(xPx, baseMudY)
    }
    
    edgePath.lineTo(w, h)
    edgePath.close()
    
    drawPath(
        path = edgePath,
        color = Color(0xFF2C1910) // Warm custom clay dark mud base
    )
    
    val borderStrokePath = Path()
    for (i in 0..segments) {
        val xFraction = i.toFloat() / segments
        val xPx = xFraction * w
        var baseMudY = h - (45f + 15f * Math.sin((xFraction * 2f * Math.PI) + 0.6).toFloat())
        
        activeGhosts.forEach { ghost ->
            if (!ghost.hasExitedMud && ghost.y >= 0.82f && ghost.y <= 1.12f) {
                val deltaX = Math.abs(xFraction - ghost.x)
                if (deltaX < 0.12f) {
                    val decay = Math.exp(-((deltaX / 0.05f) * (deltaX / 0.05f)).toDouble()).toFloat()
                    val pullHeight = (1.06f - ghost.y).coerceIn(0f, 0.22f) * h * 0.7f
                    baseMudY -= pullHeight * decay
                }
            }
        }
        
        activeRipples.forEach { r ->
            val deltaX = Math.abs(xFraction - r.x)
            if (deltaX < 0.22f) {
                val distanceRatio = deltaX / 0.22f
                val decay = Math.exp(-((deltaX / 0.08f) * (deltaX / 0.08f)).toDouble()).toFloat() * (1f - r.age)
                val frequencyRad = 15f
                val waveOffset = 30f * decay * Math.sin((r.age * frequencyRad - distanceRatio * 8f).toDouble()).toFloat()
                baseMudY -= waveOffset
            }
        }
        
        if (i == 0) {
            borderStrokePath.moveTo(xPx, baseMudY)
        } else {
            borderStrokePath.lineTo(xPx, baseMudY)
        }
    }
    
    drawPath(
        path = borderStrokePath,
        color = Color(0xFF5D3F2E), // Clay-colored shoreline crust
        style = Stroke(width = 5f, cap = StrokeCap.Round, join = StrokeJoin.Round)
    )
    
    drawReedBlade(Offset(20f, h - 35f), 90f, 15f)
    drawReedBlade(Offset(50f, h - 30f), 120f, 10f)
    drawReedBlade(Offset(w - 30f, h - 40f), -115f, 18f)
    drawReedBlade(Offset(w - 60f, h - 25f), -85f, 12f)
}

fun DrawScope.drawReedBlade(base: Offset, angleDeg: Float, scale: Float) {
    val reedPath = Path().apply {
        moveTo(base.x, base.y)
        quadraticTo(
            base.x + (angleDeg * 0.15f), 
            base.y - (scale * 5f), 
            base.x + (angleDeg * 0.35f), 
            base.y - (scale * 8f)
        )
        quadraticTo(
            base.x + (angleDeg * 0.20f), 
            base.y - (scale * 4f), 
            base.x + 10f, 
            base.y
        )
        close()
    }
    drawPath(path = reedPath, color = Color(0xFF142416))
}

fun DrawScope.drawMenuLogoGhost() {
    // Large centered cute ghost logo preview
    val w = size.width
    val h = size.height
    val ghostPath = Path().apply {
        moveTo(w * 0.2f, h * 0.5f)
        cubicTo(w * 0.2f, h * 0.15f, w * 0.8f, h * 0.15f, w * 0.8f, h * 0.5f)
        // wavy ribbon bottoms
        val waveW = (w * 0.6f) / 3f
        var currentX = w * 0.8f
        for (i in 0..2) {
            val nextX = currentX - waveW
            val midX = currentX - (waveW / 2f)
            quadraticTo(midX, h * 0.95f, nextX, h * 0.82f)
            currentX = nextX
        }
        lineTo(w * 0.2f, h * 0.5f)
        close()
    }
    drawPath(path = ghostPath, color = Color(0xFFE0F2F1))

    // Friendly face details
    drawCircle(color = Color(0xFF37474F), radius = w * 0.08f, center = Offset(w * 0.40f, h * 0.44f))
    drawCircle(color = Color(0xFF37474F), radius = w * 0.08f, center = Offset(w * 0.60f, h * 0.44f))
    drawCircle(color = Color(0xFFFF8A80), radius = w * 0.05f, center = Offset(w * 0.50f, h * 0.57f)) // tiny mouth
}

fun DrawScope.drawCustomSkinGhost(skin: GhostSkin) {
    // Draws standard-scale ghost skin cards
    val w = size.width
    val h = size.height

    val ghostColor = Color(skin.primaryColorVal)
    val eyeColor = Color(skin.eyeColorVal)

    val ghostPath = Path().apply {
        moveTo(w * 0.2f, h * 0.4f)
        cubicTo(w * 0.2f, h * 0.05f, w * 0.8f, h * 0.05f, w * 0.8f, h * 0.4f)
        // ribbon wave bottom
        quadraticTo(w * 0.7f, h * 0.9f, w * 0.6f, h * 0.8f)
        quadraticTo(w * 0.5f, h * 0.92f, w * 0.4f, h * 0.8f)
        quadraticTo(w * 0.3f, h * 0.9f, w * 0.2f, h * 0.8f)
        lineTo(w * 0.2f, h * 0.4f)
        close()
    }

    drawPath(path = ghostPath, color = ghostColor)

    // Eyes
    drawCircle(color = eyeColor, radius = w * 0.07f, center = Offset(w * 0.42f, h * 0.38f))
    drawCircle(color = eyeColor, radius = w * 0.07f, center = Offset(w * 0.58f, h * 0.38f))

    // Tiny white pupils
    drawCircle(color = Color.White, radius = w * 0.025f, center = Offset(w * 0.40f, h * 0.36f))
    drawCircle(color = Color.White, radius = w * 0.025f, center = Offset(w * 0.56f, h * 0.36f))

    // Tiny mouth
    val mouthPath = Path().apply {
        addOval(androidx.compose.ui.geometry.Rect(w*0.46f, h*0.48f, w*0.54f, h*0.58f))
    }
    drawPath(path = mouthPath, color = eyeColor)
}

fun DrawScope.drawGhostEntity(ghost: Ghost, activeSkinId: String) {
    if (ghost.currentScale <= 0f) return

    val w = size.width
    val screenX = ghost.x * w
    val screenY = ghost.y * size.height

    // Density conversions
    val radiusDp = ghost.sizeDp
    val density = size.height / 850f
    val rPx = radiusDp * density

    // Dying fadeout
    val baseAlpha = if (ghost.isDying) {
        val remaining = 10f - ghost.deathAnimationTicks
        (remaining / 10f).coerceIn(0f, 1f)
    } else {
        1.0f
    }

    // Apply squishy wobble width factor
    val widthPx = rPx * ghost.wobbleFactor * ghost.currentScale
    val heightPx = rPx * (2f - ghost.wobbleFactor) * ghost.currentScale

    val halfW = widthPx / 2f
    val hTop = heightPx * 0.45f
    val hBot = heightPx * 0.55f

    // Save canvas, rotate and translate
    drawContext.canvas.save()
    drawContext.canvas.rotate(ghost.floatRotation, screenX, screenY)

    when (ghost.type) {
        EnemyType.REGULAR -> {
            // ---> IMAGE 1: Cute Clay Ghost <---
            val bodyColor = Color(0xFF8D4F2E).copy(alpha = baseAlpha)
            val shadowColor = Color(0xFF6B3B21).copy(alpha = baseAlpha)
            val eyeColor = Color.White.copy(alpha = baseAlpha)

            // 1. Draw main body & scallops bottom
            val path = Path().apply {
                // Head dome
                moveTo(screenX - halfW, screenY)
                cubicTo(
                    screenX - halfW, screenY - hTop,
                    screenX + halfW, screenY - hTop,
                    screenX + halfW, screenY
                )
                // Down sides
                lineTo(screenX + halfW, screenY + hBot)
                // Scallops: 4 beautiful hanging drip points
                val step = widthPx / 4f
                for (i in 0..3) {
                    val currX = screenX + halfW - (i * step)
                    val nextX = screenX + halfW - ((i + 1) * step)
                    val peakY = screenY + hBot + (rPx * 0.18f)
                    quadraticTo(currX - step * 0.5f, peakY, nextX, screenY + hBot)
                }
                close()
            }
            drawPath(path = path, color = bodyColor)
            
            // Subtle clay shadow on the left side
            val shadowPath = Path().apply {
                moveTo(screenX - halfW, screenY)
                cubicTo(
                    screenX - halfW, screenY - hTop,
                    screenX - halfW * 0.2f, screenY - hTop,
                    screenX - halfW * 0.2f, screenY + hBot
                )
                lineTo(screenX - halfW, screenY + hBot)
                close()
            }
            drawPath(path = shadowPath, color = shadowColor.copy(alpha = 0.25f * baseAlpha))

            // 2. Draw big glowing white eyes
            val eyeRadius = rPx * 0.14f * ghost.currentScale
            val lEyeX = screenX - halfW * 0.35f
            val rEyeX = screenX + halfW * 0.35f
            val eyeY = screenY - hTop * 0.1f

            drawCircle(color = eyeColor, radius = eyeRadius, center = Offset(lEyeX, eyeY))
            drawCircle(color = eyeColor, radius = eyeRadius, center = Offset(rEyeX, eyeY))
            
            // Soft glow background behind eyes
            drawCircle(color = Color.White.copy(alpha = 0.25f * baseAlpha), radius = eyeRadius * 1.3f, center = Offset(lEyeX, eyeY))
            drawCircle(color = Color.White.copy(alpha = 0.25f * baseAlpha), radius = eyeRadius * 1.3f, center = Offset(rEyeX, eyeY))

            // 3. Smiling mouth
            val mouthPath = Path().apply {
                addArc(
                    oval = androidx.compose.ui.geometry.Rect(screenX - rPx * 0.08f, screenY + hBot * 0.15f, screenX + rPx * 0.08f, screenY + hBot * 0.35f),
                    startAngleDegrees = 0f,
                    sweepAngleDegrees = 180f
                )
            }
            drawPath(path = mouthPath, color = shadowColor, style = Stroke(width = 4f, cap = StrokeCap.Round))

            // 4. Blobby little waving arms on sides
            drawLine(
                color = bodyColor,
                start = Offset(screenX - halfW, screenY + hBot * 0.1f),
                end = Offset(screenX - halfW - rPx * 0.2f, screenY + hBot * 0.25f),
                strokeWidth = rPx * 0.1f,
                cap = StrokeCap.Round
            )
            drawLine(
                color = bodyColor,
                start = Offset(screenX + halfW, screenY + hBot * 0.1f),
                end = Offset(screenX + halfW + rPx * 0.2f, screenY + hBot * 0.25f),
                strokeWidth = rPx * 0.1f,
                cap = StrokeCap.Round
            )
        }
        
        EnemyType.SPEEDY -> {
            // ---> IMAGE 2: Veiny Angry Clay Ghost <---
            val bodyColor = Color(0xFF5D2F1B).copy(alpha = baseAlpha)
            val edgeColor = Color(0xFF381B0E).copy(alpha = baseAlpha)
            val veinColor = Color(0xFFFFD4A0).copy(alpha = baseAlpha) // Clay light yellowish crack glows
            val eyeColor = Color.White.copy(alpha = baseAlpha)

            // 1. Draw angry body
            val path = Path().apply {
                moveTo(screenX - halfW, screenY)
                cubicTo(
                    screenX - halfW, screenY - hTop,
                    screenX + halfW, screenY - hTop,
                    screenX + halfW, screenY
                )
                lineTo(screenX + halfW, screenY + hBot)
                // Spiky bottom drips
                val step = widthPx / 5f
                for (i in 0..4) {
                    val currX = screenX + halfW - (i * step)
                    val nextX = screenX + halfW - ((i + 1) * step)
                    val dropY = screenY + hBot + (rPx * 0.28f)
                    lineTo(currX - step * 0.5f, dropY)
                    lineTo(nextX, screenY + hBot)
                }
                close()
            }
            drawPath(path = path, color = bodyColor)

            // 2. Draw angry eyebrows and eyes
            val lEyeX = screenX - halfW * 0.35f
            val rEyeX = screenX + halfW * 0.35f
            val eyeY = screenY - hTop * 0.1f
            val eyeW = rPx * 0.15f * ghost.currentScale
            val eyeH = rPx * 0.08f * ghost.currentScale

            // Left slanted angry eye
            val lEyePath = Path().apply {
                moveTo(lEyeX - eyeW, eyeY - eyeH)
                lineTo(lEyeX + eyeW, eyeY)
                lineTo(lEyeX - eyeW * 0.5f, eyeY + eyeH)
                close()
            }
            drawPath(path = lEyePath, color = eyeColor)
            
            // Right slanted angry eye
            val rEyePath = Path().apply {
                moveTo(rEyeX + eyeW, eyeY - eyeH)
                lineTo(rEyeX - eyeW, eyeY)
                lineTo(rEyeX + eyeW * 0.5f, eyeY + eyeH)
                close()
            }
            drawPath(path = rEyePath, color = eyeColor)

            // Angry glowing crackly storm background around eyes
            drawCircle(color = Color(0xFFFFC107).copy(alpha = 0.3f * baseAlpha), radius = rPx * 0.25f, center = Offset(screenX, eyeY))

            // 3. Electric / Rooty vein cracks across face & arms
            val veinPath = Path().apply {
                // Crack 1
                moveTo(screenX, eyeY)
                lineTo(screenX - halfW * 0.2f, screenY + hBot * 0.1f)
                lineTo(screenX - halfW * 0.5f, screenY + hBot * 0.3f)
                // Crack 2
                moveTo(lEyeX - eyeW, eyeY)
                lineTo(screenX - halfW * 0.7f, eyeY + hTop * 0.3f)
                // Crack 3
                moveTo(rEyeX + eyeW, eyeY)
                lineTo(screenX + halfW * 0.7f, eyeY + hTop * 0.3f)
            }
            drawPath(path = veinPath, color = veinColor, style = Stroke(width = 3f, cap = StrokeCap.Round))

            // 4. Branchy root wraps around body (vines)
            drawCircle(
                color = edgeColor.copy(alpha = 0.4f * baseAlpha),
                radius = halfW * 0.8f,
                style = Stroke(width = 5f),
                center = Offset(screenX, screenY + hBot * 0.2f)
            )

            // 5. Dripping spiky larger hands
            drawLine(
                color = bodyColor,
                start = Offset(screenX - halfW * 0.9f, screenY + hBot * 0.1f),
                end = Offset(screenX - halfW - rPx * 0.3f, screenY + hBot * 0.4f),
                strokeWidth = rPx * 0.12f,
                cap = StrokeCap.Round
            )
            drawLine(
                color = bodyColor,
                start = Offset(screenX + halfW * 0.9f, screenY + hBot * 0.1f),
                end = Offset(screenX + halfW + rPx * 0.3f, screenY + hBot * 0.4f),
                strokeWidth = rPx * 0.12f,
                cap = StrokeCap.Round
            )
        }

        EnemyType.TANK -> {
            // ---> IMAGE 4: Buff Muscular Clay Ghost <---
            val skinColor = Color(0xFF9E5330).copy(alpha = baseAlpha)
            val shadowColor = Color(0xFF7A3E21).copy(alpha = baseAlpha)
            val eyeColor = Color.White.copy(alpha = baseAlpha)

            // 1. Muscular Silhouette (broad chest, narrow waist, big shoulders)
            val musclesPath = Path().apply {
                // Wide shoulders structure
                moveTo(screenX - halfW * 1.3f, screenY - hTop * 0.2f)
                // Head dome
                cubicTo(
                    screenX - halfW * 0.8f, screenY - hTop * 1.1f,
                    screenX + halfW * 0.8f, screenY - hTop * 1.1f,
                    screenX + halfW * 1.3f, screenY - hTop * 0.2f
                )
                // Huge massive chest outline
                lineTo(screenX + halfW * 1.2f, screenY + hBot * 0.2f)
                // Tapered waist/bell-shape at base
                lineTo(screenX + halfW * 0.8f, screenY + hBot * 0.8f)
                // Bottom ruffles/droplets
                quadraticTo(screenX, screenY + hBot * 1.05f, screenX - halfW * 0.8f, screenY + hBot * 0.8f)
                lineTo(screenX - halfW * 1.2f, screenY + hBot * 0.2f)
                close()
            }
            drawPath(path = musclesPath, color = skinColor)

            // 2. Powerful chest shadow division and highlights
            // Drawn as 2 massive chest Pecs
            val pecY = screenY + hBot * 0.1f
            val pecW = halfW * 0.45f
            val pecH = hBot * 0.3f
            
            drawRoundRect(
                color = shadowColor,
                topLeft = Offset(screenX - halfW * 0.5f, pecY),
                size = androidx.compose.ui.geometry.Size(pecW, pecH),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f),
                style = Stroke(width = 4f)
            )
            drawRoundRect(
                color = shadowColor,
                topLeft = Offset(screenX + halfW * 0.05f, pecY),
                size = androidx.compose.ui.geometry.Size(pecW, pecH),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f),
                style = Stroke(width = 4f)
            )

            // 3. Defined 8-pack Abs on the middle
            val absStartY = pecY + pecH + 5f
            val absW = halfW * 0.33f
            val absH = hBot * 0.12f
            for (row in 0..3) {
                val rowY = absStartY + (row * (absH + 4f))
                // Draw left ab
                drawRoundRect(
                    color = shadowColor,
                    topLeft = Offset(screenX - halfW * 0.38f, rowY),
                    size = androidx.compose.ui.geometry.Size(absW, absH),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f),
                    style = Stroke(width = 3f)
                )
                // Draw right ab
                drawRoundRect(
                    color = shadowColor,
                    topLeft = Offset(screenX + halfW * 0.05f, rowY),
                    size = androidx.compose.ui.geometry.Size(absW, absH),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f),
                    style = Stroke(width = 3f)
                )
            }

            // 4. Angry glowing white eyes (very intense!)
            val lEyeX = screenX - halfW * 0.3f
            val rEyeX = screenX + halfW * 0.3f
            val eyeY = screenY - hTop * 0.4f
            val eyeRad = rPx * 0.13f * ghost.currentScale
            
            drawCircle(color = eyeColor, radius = eyeRad, center = Offset(lEyeX, eyeY))
            drawCircle(color = eyeColor, radius = eyeRad, center = Offset(rEyeX, eyeY))
            drawLine(color = shadowColor, start = Offset(lEyeX - eyeRad, eyeY - eyeRad), end = Offset(lEyeX + eyeRad * 1.5f, eyeY - eyeRad * 0.2f), strokeWidth = 5f)
            drawLine(color = shadowColor, start = Offset(rEyeX + eyeRad, eyeY - eyeRad), end = Offset(rEyeX - eyeRad * 1.5f, eyeY - eyeRad * 0.2f), strokeWidth = 5f)

            // 5. Massive Biceps flexed on the side
            // Left bicep loop
            val lBicep = Path().apply {
                addOval(androidx.compose.ui.geometry.Rect(screenX - halfW * 1.6f, screenY, screenX - halfW * 1.2f, screenY + hBot * 0.4f))
            }
            drawPath(lBicep, color = skinColor)
            drawPath(lBicep, color = shadowColor, style = Stroke(width = 3f))

            // Right bicep loop
            val rBicep = Path().apply {
                addOval(androidx.compose.ui.geometry.Rect(screenX + halfW * 1.2f, screenY, screenX + halfW * 1.6f, screenY + hBot * 0.4f))
            }
            drawPath(rBicep, color = skinColor)
            drawPath(rBicep, color = shadowColor, style = Stroke(width = 3f))
        }

        EnemyType.BOSS -> {
            // ---> IMAGE 3: King Clay Ghost with Crown & Donut Scepter <---
            val skinColor = Color(0xFF7C3F1F).copy(alpha = baseAlpha)
            val shadowColor = Color(0xFF5A2A14).copy(alpha = baseAlpha)
            val crownGold = Color(0xFFFF9800).copy(alpha = baseAlpha) // Gold / Orange Chocolate crown
            val eyeColor = Color.White.copy(alpha = baseAlpha)

            // 1. Cape behind the shoulders
            val capePath = Path().apply {
                moveTo(screenX - halfW * 1.2f, screenY + hBot * 0.1f)
                lineTo(screenX - halfW * 1.6f, screenY + hBot * 0.9f)
                lineTo(screenX + halfW * 1.6f, screenY + hBot * 0.9f)
                lineTo(screenX + halfW * 1.2f, screenY + hBot * 0.1f)
                close()
            }
            drawPath(capePath, color = Color(0xFFC62828).copy(alpha = baseAlpha)) // Rich dark red cape!

            // 2. Draw King silhouette (well-built shoulders, dome head, drippy bottom)
            val path = Path().apply {
                moveTo(screenX - halfW, screenY)
                cubicTo(
                    screenX - halfW, screenY - hTop,
                    screenX + halfW, screenY - hTop,
                    screenX + halfW, screenY
                )
                lineTo(screenX + halfW, screenY + hBot)
                // Drippy scallops
                val step = widthPx / 4f
                for (i in 0..3) {
                    val currX = screenX + halfW - (i * step)
                    val nextX = screenX + halfW - ((i + 1) * step)
                    val dropY = screenY + hBot + (rPx * 0.20f)
                    quadraticTo(currX - step * 0.5f, dropY, nextX, screenY + hBot)
                }
                close()
            }
            drawPath(path = path, color = skinColor)

            // 3. Smug Confident Smiling Face & Glowing Eyes
            val lEyeX = screenX - halfW * 0.35f
            val rEyeX = screenX + halfW * 0.35f
            val eyeY = screenY - hTop * 0.15f
            val eyeRad = rPx * 0.13f * ghost.currentScale

            // Glowing narrow smug eyes
            drawCircle(color = eyeColor, radius = eyeRad, center = Offset(lEyeX, eyeY))
            drawCircle(color = eyeColor, radius = eyeRad, center = Offset(rEyeX, eyeY))
            // Smug half-lids
            drawLine(color = shadowColor, start = Offset(lEyeX - eyeRad, eyeY - eyeRad * 0.3f), end = Offset(lEyeX + eyeRad, eyeY - eyeRad * 0.1f), strokeWidth = 5f)
            drawLine(color = shadowColor, start = Offset(rEyeX - eyeRad, eyeY - eyeRad * 0.1f), end = Offset(rEyeX + eyeRad, eyeY - eyeRad * 0.3f), strokeWidth = 5f)

            // Smug grinning wide mouth
            val smirk = Path().apply {
                moveTo(screenX - halfW * 0.25f, screenY + hBot * 0.25f)
                quadraticTo(screenX + halfW * 0.1f, screenY + hBot * 0.45f, screenX + halfW * 0.35f, screenY + hBot * 0.2f)
            }
            drawPath(smirk, color = shadowColor, style = Stroke(width = 4f, cap = StrokeCap.Round))

            // 4. Gold Crown with drippy points
            val crownPath = Path().apply {
                // Crown base resting on dome head
                moveTo(screenX - halfW * 0.6f, screenY - hTop * 0.95f)
                lineTo(screenX + halfW * 0.6f, screenY - hTop * 0.95f)
                // 5 Points from right to left
                lineTo(screenX + halfW * 0.5f, screenY - hTop * 1.5f) // Point 5
                lineTo(screenX + halfW * 0.3f, screenY - hTop * 1.15f)
                lineTo(screenX + halfW * 0.2f, screenY - hTop * 1.65f) // Point 4 (inner tall)
                lineTo(screenX, screenY - hTop * 1.2f)
                lineTo(screenX - halfW * 0.2f, screenY - hTop * 1.65f) // Point 2 (inner tall)
                lineTo(screenX - halfW * 0.3f, screenY - hTop * 1.15f)
                lineTo(screenX - halfW * 0.5f, screenY - hTop * 1.5f) // Point 1
                close()
            }
            drawPath(crownPath, color = crownGold)
            drawPath(crownPath, color = shadowColor, style = Stroke(width = 3f))

            // 5. Left hand holding Chocolate Donut Scepter!
            // Scepter Staff
            val handX = screenX - halfW * 0.8f
            val handY = screenY + hBot * 0.3f
            drawLine(
                color = Color(0xFF6D4C41).copy(alpha = baseAlpha), // wooden brown
                start = Offset(handX - rPx * 0.15f, handY + rPx * 0.6f),
                end = Offset(handX + rPx * 0.35f, handY - rPx * 0.9f),
                strokeWidth = 6f,
                cap = StrokeCap.Round
            )

            // Frosted Donut head
            val donutCenterX = handX + rPx * 0.35f
            val donutCenterY = handY - rPx * 0.9f
            val donutOuterR = rPx * 0.23f
            val donutInnerR = rPx * 0.08f

            // Donut base
            drawCircle(color = Color(0xFF8D6E63).copy(alpha = baseAlpha), radius = donutOuterR, center = Offset(donutCenterX, donutCenterY))
            // Frosting (cute chocolate glaze)
            drawCircle(color = shadowColor, radius = donutOuterR * 0.85f, center = Offset(donutCenterX + 2f, donutCenterY + 2f))
            // Hole puncher
            drawCircle(color = Color(0xFF0E1A16).copy(alpha = baseAlpha), radius = donutInnerR, center = Offset(donutCenterX, donutCenterY))

            // Cute sprinkle dots
            drawCircle(color = Color.Red.copy(alpha = baseAlpha), radius = 2f, center = Offset(donutCenterX - 8f, donutCenterY - 4f))
            drawCircle(color = Color.Green.copy(alpha = baseAlpha), radius = 2f, center = Offset(donutCenterX + 8f, donutCenterY + 4f))
            drawCircle(color = Color.Yellow.copy(alpha = baseAlpha), radius = 2f, center = Offset(donutCenterX - 4f, donutCenterY + 8f))

            // Scepter hand holding it
            drawCircle(color = skinColor, radius = rPx * 0.12f, center = Offset(handX, handY))
            drawCircle(color = shadowColor, radius = rPx * 0.12f, style = Stroke(width = 2f), center = Offset(handX, handY))

            // Right hand gesturing smugly
            drawLine(
                color = skinColor,
                start = Offset(screenX + halfW, screenY + hBot * 0.2f),
                end = Offset(screenX + halfW + rPx * 0.25f, screenY + hBot * 0.1f),
                strokeWidth = rPx * 0.09f,
                cap = StrokeCap.Round
            )
        }
    }

    drawContext.canvas.restore()
}

fun DrawScope.drawCrossX(x: Float, y: Float, size: Float, color: Color) {
    drawLine(color = color, start = Offset(x - size, y - size), end = Offset(x + size, y + size), strokeWidth = 5f)
    drawLine(color = color, start = Offset(x - size, y + size), end = Offset(x + size, y - size), strokeWidth = 5f)
}

fun DrawScope.drawMudBubbleElement(bubble: MudBubble) {
    val bX = bubble.x * size.width
    val bY = bubble.y * size.height
    val rad = bubble.size

    if (bubble.burstProgress > 0f) {
        // Draw expanding outline ring fadeout
        val alpha = (1.0f - bubble.burstProgress).coerceIn(0f, 1f)
        drawCircle(
            color = Color(0xFF6D4C41).copy(alpha = alpha),
            radius = rad * (1.0f + bubble.burstProgress * 1.5f),
            style = Stroke(width = 3f),
            center = Offset(bX, bY)
        )
    } else {
        // Draw solid glossy slime bubble
        drawCircle(
            color = Color(0xFF2E3D30).copy(alpha = 0.4f),
            radius = rad,
            center = Offset(bX, bY)
        )
        // Highshine glint
        drawCircle(
            color = Color.White.copy(alpha = 0.25f),
            radius = rad * 0.25f,
            center = Offset(bX - (rad * 0.35f), bY - (rad * 0.35f))
        )
    }
}

fun DrawScope.drawParticleElement(particle: SplashParticle) {
    if (particle.alpha <= 0) return
    // Simple colored splatter droplet
    drawCircle(
        color = Color(particle.colorHex).copy(alpha = particle.alpha),
        radius = particle.currentSize,
        center = Offset(particle.x, particle.y)
    )
}

fun DrawScope.drawFogElement(cloud: FogCloud) {
    val designScale = size.height / 850f
    
    // Smooth translucent drifting cloud blobs
    val screenX = cloud.x * size.width
    val screenY = cloud.y * size.height
    val radius = cloud.size * designScale

    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(Color(0xFF263A29).copy(alpha = cloud.alpha), Color.Transparent),
            center = Offset(screenX, screenY),
            radius = radius
        ),
        radius = radius,
        center = Offset(screenX, screenY)
    )
}
