package com.example.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

object SoundSynth {
    private const val SAMPLE_RATE = 22050
    private const val TAG = "SoundSynth"

    fun playPop() {
        playWaveform(durationMs = 90) { sampleIndex, totalSamples ->
            // Sine wave ramping up in frequency (delightful popped sensation)
            val progress = sampleIndex.toDouble() / totalSamples
            val freq = 350.0 + (progress * 650.0) // 350Hz up to 1000Hz
            val volume = 1.0 - progress // Quick fade-out
            val angle = sampleIndex * 2.0 * Math.PI * freq / SAMPLE_RATE
            (Math.sin(angle) * Short.MAX_VALUE * 0.7 * volume).toInt().toShort()
        }
    }

    fun playSplash() {
        playWaveform(durationMs = 180) { sampleIndex, totalSamples ->
            // Squishy wet splat: Combination of white noise and low rumble
            val progress = sampleIndex.toDouble() / totalSamples
            val volume = 1.0 - progress
            val waveAngle = sampleIndex * 2.0 * Math.PI * 110.0 / SAMPLE_RATE
            val noise = (Math.random() * 2.0 - 1.0) * Short.MAX_VALUE * 0.4
            val lowTone = Math.sin(waveAngle) * Short.MAX_VALUE * 0.6
            ((lowTone + noise) * volume).toInt().toShort()
        }
    }

    fun playComboUp(multiplier: Int) {
        // High pitch blip scaling exponentially with combo multipliers
        val baseFreq = 440.0 + (multiplier * 200.0)
        playWaveform(durationMs = 120) { sampleIndex, totalSamples ->
            val progress = sampleIndex.toDouble() / totalSamples
            val volume = 1.0 - progress
            val angle = sampleIndex * 2.0 * Math.PI * baseFreq / SAMPLE_RATE
            // Triangle-like wave for crisp arcade blip style
            val sine = Math.sin(angle)
            val wave = if (sine >= 0) sine else -sine // Absolute sine acts like double octave
            (wave * Short.MAX_VALUE * 0.6 * volume).toInt().toShort()
        }
    }

    fun playMiss() {
        // Flat buzz indicating standard failure
        playWaveform(durationMs = 250) { sampleIndex, totalSamples ->
            val progress = sampleIndex.toDouble() / totalSamples
            val volume = 1.0 - progress
            val angle = sampleIndex * 2.0 * Math.PI * 90.0 / SAMPLE_RATE
            // Harsh square wave
            val wave = if (Math.sin(angle) >= 0) Short.MAX_VALUE * 0.3 else -Short.MAX_VALUE * 0.3
            (wave * volume).toInt().toShort()
        }
    }

    fun playGameOver() {
        CoroutineScope(Dispatchers.Default).launch {
            try {
                playWaveTone(440.0, 180)
                kotlinx.coroutines.delay(200)
                playWaveTone(349.23, 180) // F4
                kotlinx.coroutines.delay(200)
                playWaveTone(293.66, 350) // D4 sad long note
            } catch (e: Exception) {
                Log.e(TAG, "Error playing gameover sound", e)
            }
        }
    }

    private fun playWaveTone(freq: Double, durationMs: Int) {
        playWaveform(durationMs) { sampleIndex, totalSamples ->
            val progress = sampleIndex.toDouble() / totalSamples
            val volume = 1.0 - progress
            val angle = sampleIndex * 2.0 * Math.PI * freq / SAMPLE_RATE
            (Math.sin(angle) * Short.MAX_VALUE * 0.5 * volume).toInt().toShort()
        }
    }

    private fun playWaveform(durationMs: Int = 80, generator: (Int, Int) -> Short) {
        CoroutineScope(Dispatchers.Default).launch {
            try {
                val totalSamples = (SAMPLE_RATE * (durationMs / 1000.0)).toInt()
                if (totalSamples <= 0) return@launch
                val buffer = ShortArray(totalSamples)
                for (i in 0 until totalSamples) {
                    buffer[i] = generator(i, totalSamples)
                }

                val audioTrack = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(SAMPLE_RATE)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(buffer.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()

                audioTrack.write(buffer, 0, buffer.size)
                audioTrack.play()
                
                // Static playback needs delay to complete before release
                kotlinx.coroutines.delay(durationMs.toLong() + 30)
                audioTrack.release()
            } catch (e: Exception) {
                Log.e(TAG, "Dynamic audio track creation failed: ${e.message}")
            }
        }
    }
}
