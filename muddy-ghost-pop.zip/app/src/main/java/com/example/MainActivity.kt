package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.MainMenuScreen
import com.example.ui.PlayingScreen
import com.example.ui.ShopScreen
import com.example.ui.SimulatedAdDisplay
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.AdState
import com.example.viewmodel.GameUiState
import com.example.viewmodel.GameViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val viewModel: GameViewModel = viewModel()
                val state by viewModel.gameState.collectAsStateWithLifecycle()
                val context = LocalContext.current

                // React to native ad toasts inside the app loop gracefully
                LaunchedEffect(state.showAdToast) {
                    state.showAdToast?.let { msg ->
                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    }
                }

                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF040604)
                ) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        
                        // --- Base UI States ---
                        when (state.uiState) {
                            is GameUiState.MainMenu -> {
                                MainMenuScreen(
                                    state = state,
                                    onStartGame = { viewModel.changeUiState(GameUiState.Playing) },
                                    onOpenShop = { viewModel.changeUiState(GameUiState.Shop) }
                                )
                            }
                            is GameUiState.Shop -> {
                                BackHandler {
                                    viewModel.changeUiState(GameUiState.MainMenu)
                                }
                                ShopScreen(
                                    state = state,
                                    onBack = { viewModel.changeUiState(GameUiState.MainMenu) },
                                    onSelectSkin = { skinId -> viewModel.selectSkin(skinId) },
                                    onPurchaseSkin = { skin -> viewModel.purchaseSkin(skin) }
                                )
                            }
                            is GameUiState.Playing -> {
                                BackHandler {
                                    viewModel.changeUiState(GameUiState.MainMenu)
                                }
                                PlayingScreen(
                                    state = state,
                                    activeGhosts = viewModel.activeGhosts,
                                    activeBubbles = viewModel.activeBubbles,
                                    activeParticles = viewModel.activeParticles,
                                    activeClouds = viewModel.activeClouds,
                                    activeRipples = viewModel.activeRipples,
                                    onGestureTap = { width, height, tx, ty ->
                                        viewModel.onUserTap(width, height, tx, ty)
                                    },
                                    onRestart = { viewModel.changeUiState(GameUiState.Playing) },
                                    onMenu = { viewModel.changeUiState(GameUiState.MainMenu) },
                                    onWatchDouble = { viewModel.watchRewardedAdDouble() },
                                    onWatchRevive = { viewModel.watchRewardedAdRevive() }
                                )
                            }
                        }

                        // --- Interactive Ad Overlays ---
                        if (state.adState != AdState.IDLE) {
                            SimulatedAdDisplay(
                                adState = state.adState,
                                countdown = state.adCountdown,
                                onSkip = { viewModel.dismissAd() }
                            )
                        }

                        // --- Dynamic HUD Floating Ad Toast Alert Bubble ---
                        state.showAdToast?.let { toastText ->
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 90.dp)
                                    .align(Alignment.TopCenter),
                                contentAlignment = Alignment.Center
                            ) {
                                Surface(
                                    color = Color(0xFF1B5E20),
                                    shape = RoundedCornerShape(20.dp),
                                    shadowElevation = 10.dp
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 24.dp, vertical = 10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Favorite,
                                            contentDescription = "Notification",
                                            tint = Color(0xFFFFD700),
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = toastText.uppercase(),
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace,
                                            letterSpacing = 1.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
