package com.example.database

import android.content.Context
import androidx.room.*

@Entity(tableName = "highscore")
data class HighscoreEntity(
    @PrimaryKey val id: Int = 1,
    val score: Int
)

@Entity(tableName = "unlocked_skins")
data class UnlockedSkinEntity(
    @PrimaryKey val skinId: String
)

@Entity(tableName = "points")
data class PointsEntity(
    @PrimaryKey val id: Int = 1,
    val points: Int
)

@Dao
interface GameDao {
    @Query("SELECT score FROM highscore WHERE id = 1")
    suspend fun getHighScore(): Int?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveHighScore(entity: HighscoreEntity)

    @Query("SELECT points FROM points WHERE id = 1")
    suspend fun getPoints(): Int?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun savePoints(entity: PointsEntity)

    @Query("SELECT skinId FROM unlocked_skins")
    suspend fun getUnlockedSkinIds(): List<String>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun unlockSkin(entity: UnlockedSkinEntity)
}

@Database(
    entities = [HighscoreEntity::class, UnlockedSkinEntity::class, PointsEntity::class],
    version = 2,
    exportSchema = false
)
abstract class GameDatabase : RoomDatabase() {
    abstract fun gameDao(): GameDao

    companion object {
        @Volatile
        private var INSTANCE: GameDatabase? = null

        fun getDatabase(context: Context): GameDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    GameDatabase::class.java,
                    "muddy_phantoms_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
