package com.example.model

enum class EnemyType {
    REGULAR,
    SPEEDY,
    TANK,
    BOSS
}

data class GroundRipple(
    val x: Float, // horizontal position fraction 0f..1f
    var age: Float, // ripple progression 0f..1f
    val speed: Float = 0.035f // lifespan decay speed
)

data class Ghost(
    val id: String,
    var x: Float, // horizontal position fraction (0.0f..1.0f)
    var y: Float, // vertical position fraction (0.5f..1.2f from bottom spawn going up to -0.2f)
    val type: EnemyType,
    val speed: Float, // float speed per frame/tick
    val maxHp: Int,
    var hp: Int,
    val sizeDp: Float, // visual size dimensions
    val horizontalWobbleAmp: Float, // drift amplitude 
    val horizontalWobbleFreq: Float, // drift speed
    val spawnTime: Long, // creation time
    var currentScale: Float = 0.0f, // starts at 0f for popping scale emergence
    var wobbleFactor: Float = 1.0f, // width compress factor for squishy animation
    var floatRotation: Float = 0f, // subtle float tilt
    var isDying: Boolean = false, // transition flag
    var deathAnimationTicks: Int = 0,
    var hasExitedMud: Boolean = false // Track if broke mud boundary
)

data class SplashParticle(
    val id: Long,
    var x: Float, // exact canvas-space or fraction-space coordinates
    var y: Float,
    var vx: Float,
    var vy: Float,
    var colorHex: Long,
    var baseSize: Float,
    var currentSize: Float,
    var alpha: Float = 1.0f,
    var lifeRemaining: Float = 1.0f // decays toward 0.0
)

data class MudBubble(
    val id: Long,
    var x: Float,
    var y: Float,
    val size: Float,
    val speed: Float,
    var burstProgress: Float = 0f // 0 = standard floating, >0 = bursting
)

data class FogCloud(
    val id: Long,
    var x: Float,
    var y: Float,
    val size: Float,
    val speed: Float,
    val alpha: Float,
    val wobbleOffset: Float
)

data class GhostSkin(
    val id: String,
    val name: String,
    val cost: Int,
    val label: String, // Mini Turkish/English label
    val primaryColorVal: Long, // Color tint for ghost fabric
    val eyeColorVal: Long, // Color of glowing eyes
    val particleColorVal: Long // Color of explosion splashes
) {
    companion object {
        val ALL_SKINS = listOf(
            GhostSkin("classic", "Classic Casper", 0, "Bataklık Pamuğu", 0xFFE0F2F1, 0xFF37474F, 0xFFB2DFDB),
            GhostSkin("toxic", "Toxic Ooze", 1000, "Vıcık Zehir", 0xFF5AF74A, 0xFFFF003C, 0xFFCFFFD2),
            GhostSkin("poison", "Poison Eye", 2500, "Violet Nazar", 0xFFD500F9, 0xFFFFFF00, 0xFFF3CFFF),
            GhostSkin("golden", "Sovereign Spook", 5000, "Altın Batak", 0xFFFFD700, 0xFF4E342E, 0xFFFFF9C4)
        )
    }
}
