package com.example.viewmodel

import android.app.Application
import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.SoundSynth
import com.example.database.GameDatabase
import com.example.database.HighscoreEntity
import com.example.database.PointsEntity
import com.example.database.UnlockedSkinEntity
import com.example.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

sealed class GameUiState {
    object MainMenu : GameUiState()
    object Playing : GameUiState()
    object Shop : GameUiState()
}

enum class AdState {
    IDLE,
    SHOWING_INTERSTITIAL,
    SHOWING_REWARDED_DOUBLE,
    SHOWING_REWARDED_REVIVE
}

data class GameState(
    val highscore: Int = 0,
    val score: Int = 0,
    val swampPoints: Int = 0,
    val comboCount: Int = 0,
    val comboMultiplier: Int = 1,
    val comboGauge: Float = 0f, // 1.0f down to 0.0f
    val lives: Int = 3,
    val isGameOver: Boolean = false,
    val activeSkinId: String = "classic",
    val unlockedSkins: Set<String> = setOf("classic"),
    val uiState: GameUiState = GameUiState.MainMenu,
    val adState: AdState = AdState.IDLE,
    val adCountdown: Int = 5,
    val showAdToast: String? = null,
    val totalGamesPlayed: Int = 0
)

class GameViewModel(application: Application) : AndroidViewModel(application) {

    private val database = GameDatabase.getDatabase(application)
    private val dao = database.gameDao()

    private val _gameState = MutableStateFlow(GameState())
    val gameState: StateFlow<GameState> = _gameState.asStateFlow()

    // Active Entity Collections (Managed dynamically with direct lists for frame accuracy)
    val activeGhosts = mutableStateListOf<Ghost>()
    val activeBubbles = mutableStateListOf<MudBubble>()
    val activeParticles = mutableStateListOf<SplashParticle>()
    val activeClouds = mutableStateListOf<FogCloud>()
    val activeRipples = mutableStateListOf<GroundRipple>()

    // Object Pooling Systems
    private val particlePool = ArrayList<SplashParticle>(100)
    private val bubblePool = ArrayList<MudBubble>(20)

    // Game loop control
    private var gameLoopJob: Job? = null
    private var lastFrameTime: Long = 0L

    // Difficulty params
    private var elapsedTime: Float = 0f
    private var baseSpawnInterval: Long = 1800L
    private var lastSpawnTime: Long = 0L
    
    // Combo timer
    private var lastKillTime: Long = 0L
    private val COMBO_COOLDOWN_MS = 2500L

    // Particle ID Counter
    private var particleIdCounter = 0L

    init {
        // Load persistences
        viewModelScope.launch(Dispatchers.IO) {
            val highVal = dao.getHighScore() ?: 0
            val pointsVal = dao.getPoints() ?: 0
            val unlockedSet = dao.getUnlockedSkinIds().toSet() + "classic"
            
            _gameState.update {
                it.copy(
                    highscore = highVal,
                    swampPoints = pointsVal,
                    unlockedSkins = unlockedSet
                )
            }
        }

        // Initialize background environment
        initializeEnvironment()
    }

    private fun initializeEnvironment() {
        activeClouds.clear()
        activeBubbles.clear()
        activeRipples.clear()

        // Distribute some starting drifting clouds
        for (i in 0..3) {
            activeClouds.add(
                FogCloud(
                    id = i.toLong(),
                    x = (0.1f + i * 0.25f) + (Math.random() * 0.1f).toFloat(),
                    y = (0.1f + Math.random() * 0.5f).toFloat(),
                    size = (200f + Math.random() * 150f).toFloat(),
                    speed = (0.0004f + Math.random() * 0.0006f).toFloat(),
                    alpha = (0.2f + Math.random() * 0.2f).toFloat(),
                    wobbleOffset = (Math.random() * 100.0).toFloat()
                )
            )
        }

        // Prepopulate standard mud bubbles
        for (i in 0..5) {
            val bubble = retrieveOrCreateBubble()
            bubble.x = (0.05f + Math.random() * 0.9f).toFloat()
            bubble.y = (0.1f + Math.random() * 0.9f).toFloat()
            activeBubbles.add(bubble)
        }
    }

    // --- Object Pooling Routines ---
    private fun retrieveOrCreateBubble(): MudBubble {
        return if (bubblePool.isNotEmpty()) {
            val b = bubblePool.removeAt(bubblePool.size - 1)
            b.burstProgress = 0f
            b.y = 1.1f
            b
        } else {
            MudBubble(
                id = UUID.randomUUID().hashCode().toLong(),
                x = 0f,
                y = 1.1f,
                size = (15f + Math.random() * 20f).toFloat(),
                speed = (0.003f + Math.random() * 0.004f).toFloat()
            )
        }
    }

    private fun recycleBubble(bubble: MudBubble) {
        if (bubblePool.size < 30) {
            bubblePool.add(bubble)
        }
    }

    private fun retrieveOrCreateParticle(): SplashParticle {
        return if (particlePool.isNotEmpty()) {
            val p = particlePool.removeAt(particlePool.size - 1)
            p.alpha = 1f
            p.lifeRemaining = 1f
            p
        } else {
            SplashParticle(
                id = ++particleIdCounter,
                x = 0f,
                y = 0f,
                vx = 0f,
                vy = 0f,
                colorHex = 0xFFFFFFFF,
                baseSize = 8f,
                currentSize = 8f
            )
        }
    }

    private fun recycleParticle(particle: SplashParticle) {
        if (particlePool.size < 150) {
            particlePool.add(particle)
        }
    }

    // --- Game Navigation Router ---
    fun changeUiState(target: GameUiState) {
        _gameState.update { it.copy(uiState = target) }
        if (target == GameUiState.Playing) {
            startGame()
        } else {
            stopGameLoop()
        }
    }

    // --- Core Game Systems ---
    private fun startGame() {
        stopGameLoop()
        
        activeGhosts.clear()
        activeParticles.clear()
        activeRipples.clear()
        elapsedTime = 0f
        lastSpawnTime = 0L
        lastFrameTime = System.currentTimeMillis()

        _gameState.update {
            it.copy(
                score = 0,
                comboCount = 0,
                comboMultiplier = 1,
                comboGauge = 0f,
                lives = 3,
                isGameOver = false,
                adState = AdState.IDLE
            )
        }

        initializeEnvironment()

        gameLoopJob = viewModelScope.launch(Dispatchers.Main) {
            while (true) {
                tickPhysics()
                delay(16) // Aim for ~60 FPS
            }
        }
    }

    private fun stopGameLoop() {
        gameLoopJob?.cancel()
        gameLoopJob = null
    }

    private fun tickPhysics() {
        val now = System.currentTimeMillis()
        val deltaMs = now - lastFrameTime
        lastFrameTime = now

        if (_gameState.value.isGameOver || _gameState.value.adState != AdState.IDLE) return

        elapsedTime += (deltaMs / 1000f)

        // Spawn logic
        updateSpawning(now)

        // Movement & Physics
        updateGhosts(now)
        updateBubbles()
        updateParticles()
        updateFog()
        updateRipples()

        // Combo system decay
        updateComboDecay(now)
    }

    private fun updateRipples() {
        val iterator = activeRipples.listIterator()
        while (iterator.hasNext()) {
            val r = iterator.next()
            r.age += r.speed
            if (r.age >= 1.0f) {
                iterator.remove()
            }
        }
    }

    private fun updateSpawning(now: Long) {
        // Difficulty scaling formula: base interval shrinks as time progresses
        val currentSpawnRate = (baseSpawnInterval - (elapsedTime * 15f).toLong()).coerceAtLeast(650L)

        if (now - lastSpawnTime >= currentSpawnRate) {
            lastSpawnTime = now
            spawnGhost(now)
        }
    }

    private fun spawnGhost(now: Long) {
        // Pick type based on difficulty progression
        val randomValue = Math.random()
        val type = when {
            elapsedTime > 55f && randomValue < 0.22 -> EnemyType.BOSS
            elapsedTime > 35f && randomValue < 0.42 -> if (Math.random() < 0.5) EnemyType.TANK else EnemyType.BOSS
            elapsedTime > 18f && randomValue < 0.50 -> if (Math.random() < 0.6) EnemyType.SPEEDY else EnemyType.TANK
            elapsedTime > 8f && randomValue < 0.40 -> EnemyType.SPEEDY
            else -> EnemyType.REGULAR
        }

        val timeHardnessMultiplier = 1.0f + (elapsedTime / 110f).coerceAtMost(0.9f)

        val speed = when (type) {
            EnemyType.REGULAR -> (0.003f + Math.random() * 0.002f).toFloat() * timeHardnessMultiplier
            EnemyType.SPEEDY -> (0.007f + Math.random() * 0.003f).toFloat() * timeHardnessMultiplier
            EnemyType.TANK -> (0.0016f + Math.random() * 0.001f).toFloat() * timeHardnessMultiplier
            EnemyType.BOSS -> (0.0010f + Math.random() * 0.0006f).toFloat() * timeHardnessMultiplier
        }

        val hp = when (type) {
            EnemyType.REGULAR -> 1
            EnemyType.SPEEDY -> 1
            EnemyType.TANK -> 3
            EnemyType.BOSS -> 5
        }

        val size = when (type) {
            EnemyType.REGULAR -> (55f + Math.random() * 12f).toFloat()
            EnemyType.SPEEDY -> (42f + Math.random() * 8f).toFloat()
            EnemyType.TANK -> (75f + Math.random() * 10f).toFloat()
            EnemyType.BOSS -> (95f + Math.random() * 10f).toFloat()
        }

        val amp = (0.015f + Math.random() * 0.02f).toFloat()
        val freq = (1.5f + Math.random() * 2f).toFloat()

        val ghost = Ghost(
            id = UUID.randomUUID().toString(),
            x = (0.15f + Math.random() * 0.7f).toFloat(),
            y = 1.15f, // Spawn just below bottom edge
            type = type,
            speed = speed,
            maxHp = hp,
            hp = hp,
            sizeDp = size,
            horizontalWobbleAmp = amp,
            horizontalWobbleFreq = freq,
            spawnTime = now
        )

        activeGhosts.add(ghost)
    }

    private fun updateGhosts(now: Long) {
        val iterator = activeGhosts.listIterator()
        while (iterator.hasNext()) {
            val ghost = iterator.next()

            if (ghost.isDying) {
                ghost.deathAnimationTicks++
                if (ghost.deathAnimationTicks > 10) {
                    iterator.remove()
                }
                continue
            }

            // Upward motion
            val prevY = ghost.y
            ghost.y -= ghost.speed

            // Check if emergence/mud boundary is broken for ground stretch and ripple!
            if (prevY >= 0.93f && ghost.y < 0.93f && !ghost.hasExitedMud) {
                ghost.hasExitedMud = true
                SoundSynth.playPop() // juicy mud pop
                activeRipples.add(GroundRipple(x = ghost.x, age = 0f))
            }

            // Floating Pop-in Bounce transition
            if (ghost.currentScale < 1.0f) {
                ghost.currentScale = (ghost.currentScale + 0.12f).coerceAtMost(1.0f)
            }

            // Squishy Wobbling factor
            val secondsSinceSpawn = (now - ghost.spawnTime) / 1000f
            ghost.wobbleFactor = 1.0f + 0.07f * Math.sin((secondsSinceSpawn * ghost.horizontalWobbleFreq * 4).toDouble()).toFloat()
            ghost.floatRotation = 6f * Math.sin((secondsSinceSpawn * 2f).toDouble()).toFloat()

            // Drift horizontally using sine wobble
            ghost.x += (Math.sin((secondsSinceSpawn * ghost.horizontalWobbleFreq).toDouble()) * ghost.horizontalWobbleAmp * 0.05).toFloat()
            ghost.x = ghost.x.coerceIn(0.02f, 0.98f)

            // Escaped check!
            if (ghost.y < -0.15f) {
                iterator.remove()
                handleGhostEscaped()
            }
        }
    }

    private fun handleGhostEscaped() {
        if (_gameState.value.isGameOver) return

        SoundSynth.playMiss()
        val livesLeft = _gameState.value.lives - 1
        _gameState.update { it.copy(lives = livesLeft) }

        // Break combo completely
        _gameState.update {
            it.copy(
                comboCount = 0,
                comboMultiplier = 1,
                comboGauge = 0f
            )
        }

        if (livesLeft <= 0) {
            triggerGameOver()
        }
    }

    private fun triggerGameOver() {
        stopGameLoop()
        SoundSynth.playGameOver()
        _gameState.update { it.copy(isGameOver = true) }

        // Update total games played
        val updatedGames = _gameState.value.totalGamesPlayed + 1
        _gameState.update { it.copy(totalGamesPlayed = updatedGames) }

        // Save Highscores & Swamp Essences
        viewModelScope.launch(Dispatchers.IO) {
            val currentScore = _gameState.value.score
            val prevHigh = dao.getHighScore() ?: 0
            if (currentScore > prevHigh) {
                dao.saveHighScore(HighscoreEntity(score = currentScore))
                _gameState.update { it.copy(highscore = currentScore) }
            }

            val addedPoints = currentScore // 1 point per score
            val currentTotalPoints = (dao.getPoints() ?: 0) + addedPoints
            dao.savePoints(PointsEntity(points = currentTotalPoints))
            _gameState.update { it.copy(swampPoints = currentTotalPoints) }
        }

        // Automatic Interstitial advertisement checker! Show ad every 2 games
        if (_gameState.value.totalGamesPlayed % 2 == 0) {
            showInterstitialAd()
        }
    }

    private fun updateBubbles() {
        val iterator = activeBubbles.listIterator()
        while (iterator.hasNext()) {
            val b = iterator.next()
            if (b.burstProgress > 0f) {
                b.burstProgress += 0.08f
                if (b.burstProgress >= 1f) {
                    iterator.remove()
                    recycleBubble(b)
                    
                    // Spawn a recycled replacement from bottom immediately
                    val replacement = retrieveOrCreateBubble()
                    replacement.x = (0.05f + Math.random() * 0.9f).toFloat()
                    replacement.y = 1.05f
                    activeBubbles.add(replacement)
                }
            } else {
                b.y -= b.speed
                if (b.y < -0.05f || (b.y < 0.2f && Math.random() < 0.004)) {
                    b.burstProgress = 0.01f // Trigger popping splash sequence
                }
            }
        }
    }

    private fun updateParticles() {
        val iterator = activeParticles.listIterator()
        while (iterator.hasNext()) {
            val p = iterator.next()
            p.x += p.vx
            p.y += p.vy
            
            // Apply air resistance gravity
            p.vy += 0.25f // weak gravity pull
            p.vx *= 0.96f // drag multiplier

            p.lifeRemaining -= 0.04f
            p.alpha = p.lifeRemaining.coerceIn(0.0f, 1.0f)
            p.currentSize = p.baseSize * p.lifeRemaining

            if (p.lifeRemaining <= 0) {
                iterator.remove()
                recycleParticle(p)
            }
        }
    }

    private fun updateFog() {
        activeClouds.forEach { cloud ->
            cloud.x += cloud.speed
            if (cloud.x > 1.4f) {
                cloud.x = -0.4f
            }
        }
    }

    private fun updateComboDecay(now: Long) {
        val st = _gameState.value
        if (st.comboCount > 0) {
            val delta = now - lastKillTime
            val percentage = 1.0f - (delta.toFloat() / COMBO_COOLDOWN_MS)
            if (percentage <= 0f) {
                _gameState.update {
                    it.copy(
                        comboCount = 0,
                        comboMultiplier = 1,
                        comboGauge = 0f
                    )
                }
            } else {
                _gameState.update { it.copy(comboGauge = percentage) }
            }
        }
    }

    // --- Inputs & Raycast Tap Detector ---
    fun onUserTap(canvasWidthPx: Float, canvasHeightPx: Float, tapX: Float, tapY: Float) {
        if (_gameState.value.isGameOver || _gameState.value.adState != AdState.IDLE || _gameState.value.uiState != GameUiState.Playing) return

        var ghostTapped: Ghost? = null
        val density = canvasHeightPx / 850f // standard normalized design height scale

        // Iterate backward so we check topmost visually layered ghosts first!
        for (i in activeGhosts.indices.reversed()) {
            val g = activeGhosts[i]
            if (g.isDying) continue

            // Convert fractions to approximate pixel centers
            val gPxX = g.x * canvasWidthPx
            val gPxY = g.y * canvasHeightPx
            val radiusPx = (g.sizeDp / 2f) * density * 1.2f // Add subtle interactive cushion/forgiveness

            val distanceSq = (tapX - gPxX) * (tapX - gPxX) + (tapY - gPxY) * (tapY - gPxY)
            if (distanceSq <= radiusPx * radiusPx) {
                ghostTapped = g
                break
            }
        }

        if (ghostTapped != null) {
            processGhostHit(ghostTapped, tapX, tapY)
        } else {
            // Screen Tap Miss
            SoundSynth.playMiss()
            _gameState.update {
                it.copy(
                    comboCount = 0,
                    comboMultiplier = 1,
                    comboGauge = 0f
                )
            }
        }
    }

    private fun processGhostHit(ghost: Ghost, tapX: Float, tapY: Float) {
        ghost.hp--
        
        // Fetch current active skin preferences for particle color
        val activeSkin = GhostSkin.ALL_SKINS.find { it.id == _gameState.value.activeSkinId } ?: GhostSkin.ALL_SKINS[0]

        if (ghost.hp <= 0) {
            ghost.isDying = true

            // Splash feedback
            SoundSynth.playSplash()
            spawnBurstParticles(tapX, tapY, activeSkin.particleColorVal)

            // Add scores
            val currentCombo = _gameState.value.comboCount + 1
            val currentMultiplier = when {
                currentCombo >= 20 -> 5
                currentCombo >= 10 -> 3
                currentCombo >= 5 -> 2
                else -> 1
            }

            // Score addition based on enemy values
            val basePoints = when (ghost.type) {
                EnemyType.REGULAR -> 10
                EnemyType.SPEEDY -> 20
                EnemyType.TANK -> 50
                EnemyType.BOSS -> 100
            }

            val addedScore = basePoints * currentMultiplier
            val updatedScore = _gameState.value.score + addedScore

            lastKillTime = System.currentTimeMillis()
            
            // Check combo jump audio triggers
            if (currentMultiplier > _gameState.value.comboMultiplier) {
                SoundSynth.playComboUp(currentMultiplier)
            } else {
                SoundSynth.playPop()
            }

            _gameState.update {
                it.copy(
                    score = updatedScore,
                    comboCount = currentCombo,
                    comboMultiplier = currentMultiplier,
                    comboGauge = 1.0f
                )
            }
        } else {
            // Hit but not dead (e.g., Tank Ghost!)
            SoundSynth.playPop()
            // Mini spark burst!
            spawnBurstParticles(tapX, tapY, 0xFF7D5A50, count = 5) // dirty debris burst
        }
    }

    private fun spawnBurstParticles(x: Float, y: Float, color: Long, count: Int = 12) {
        for (i in 0 until count) {
            val p = retrieveOrCreateParticle()
            val angle = (Math.random() * 2.0 * Math.PI)
            val velocity = (3f + Math.random() * 12f).toFloat()
            val size = (6f + Math.random() * 8f).toFloat()
            val finalColor = if (color == 0xFFE0F2F1 && Math.random() > 0.5) 0xFF4DB6AC else color

            p.x = x
            p.y = y
            p.vx = (Math.cos(angle) * velocity).toFloat()
            p.vy = (Math.sin(angle) * velocity - 2f).toFloat() // push slightly upward
            p.colorHex = finalColor
            p.baseSize = size
            p.currentSize = size
            p.alpha = 1.0f
            p.lifeRemaining = 1.0f

            activeParticles.add(p)
        }
    }

    // --- Monetization & Skinner Unlocks System ---
    fun selectSkin(skinId: String) {
        _gameState.update { it.copy(activeSkinId = skinId) }
    }

    fun purchaseSkin(skin: GhostSkin) {
        val cost = skin.cost
        val currentPoints = _gameState.value.swampPoints
        val unlocked = _gameState.value.unlockedSkins

        if (currentPoints >= cost && !unlocked.contains(skin.id)) {
            val updatedPoints = currentPoints - cost
            val updatedUnlocked = unlocked + skin.id

            viewModelScope.launch(Dispatchers.IO) {
                dao.savePoints(PointsEntity(points = updatedPoints))
                dao.unlockSkin(UnlockedSkinEntity(skinId = skin.id))
            }

            _gameState.update {
                it.copy(
                    swampPoints = updatedPoints,
                    unlockedSkins = updatedUnlocked,
                    activeSkinId = skin.id
                )
            }
            SoundSynth.playComboUp(3) // purchase fun sound!
            showAdToastMessage("Skin Unlocked: ${skin.name}!")
        } else {
            SoundSynth.playMiss()
        }
    }

    // --- Advertisement Simulation Controls ---
    fun showAdToastMessage(message: String) {
        _gameState.update { it.copy(showAdToast = message) }
        viewModelScope.launch {
            delay(2000)
            _gameState.update {
                if (it.showAdToast == message) it.copy(showAdToast = null) else it
            }
        }
    }

    private fun showInterstitialAd() {
        _gameState.update { it.copy(adState = AdState.SHOWING_INTERSTITIAL, adCountdown = 5) }
        viewModelScope.launch {
            for (i in 5 downTo 1) {
                _gameState.update { it.copy(adCountdown = i) }
                delay(1000)
            }
            dismissAd()
            showAdToastMessage("Ad skipped - Interstitial Monetization Simulated!")
        }
    }

    fun watchRewardedAdDouble() {
        _gameState.update { it.copy(adState = AdState.SHOWING_REWARDED_DOUBLE, adCountdown = 5) }
        viewModelScope.launch {
            for (i in 5 downTo 1) {
                _gameState.update { it.copy(adCountdown = i) }
                delay(1000)
            }
            val currentScore = _gameState.value.score
            val doubledScore = currentScore * 2
            _gameState.update { it.copy(score = doubledScore) }

            // Resave highscore
            val prevHigh = dao.getHighScore() ?: 0
            if (doubledScore > prevHigh) {
                dao.saveHighScore(HighscoreEntity(score = doubledScore))
                _gameState.update { it.copy(highscore = doubledScore) }
            }

            // Grant swamp coins equivalent to doubled
            val diffPoints = doubledScore - currentScore
            val totalPts = (dao.getPoints() ?: 0) + diffPoints
            dao.savePoints(PointsEntity(points = totalPts))
            _gameState.update { it.copy(swampPoints = totalPts) }

            dismissAd()
            SoundSynth.playComboUp(4)
            showAdToastMessage("Rewarded Granted - Score Doubled to $doubledScore!")
        }
    }

    fun watchRewardedAdRevive() {
        _gameState.update { it.copy(adState = AdState.SHOWING_REWARDED_REVIVE, adCountdown = 5) }
        viewModelScope.launch {
            for (i in 5 downTo 1) {
                _gameState.update { it.copy(adCountdown = i) }
                delay(1000)
            }
            dismissAd()
            
            // Revive with full lives
            _gameState.update {
                it.copy(
                    lives = 3,
                    isGameOver = false
                )
            }
            lastFrameTime = System.currentTimeMillis()
            
            // Restart game ticker
            gameLoopJob = viewModelScope.launch(Dispatchers.Main) {
                while (true) {
                    tickPhysics()
                    delay(16)
                }
            }

            SoundSynth.playComboUp(4)
            showAdToastMessage("Rewarded Granted - Reliving with 3 fresh lives!")
        }
    }

    fun dismissAd() {
        _gameState.update { it.copy(adState = AdState.IDLE) }
    }
}
