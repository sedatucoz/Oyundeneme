// =========================================================================
//              MUDDY PHANTOMS (BATAKLIK HAYALETLERİ) - UNITY C# SUITE
// =========================================================================
// This master C# file holds the complete and ready-to-use custom scripts for
// your Unity 2D Mobile projects (designed for Unity 2021+ with Touch inputs).
// Save these blocks into separate scripts in your Unity Asset folder.

using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

namespace MuddyPhantoms.Unity
{
    // =========================================================================
    // 1. SIMPLE & PERFORMANT TARGETED OBJECT POOLING SYSTEM
    // =========================================================================
    public class ObjectPooler : MonoBehaviour
    {
        public static ObjectPooler Instance;

        [System.Serializable]
        public class Pool
        {
            public string tag;
            public GameObject prefab;
            public int size;
        }

        public List<Pool> pools;
        public Dictionary<string, Queue<GameObject>> poolDictionary;

        private void Awake()
        {
            Instance = this;
            InitializePools();
        }

        private void InitializePools()
        {
            poolDictionary = new Dictionary<string, Queue<GameObject>>();

            foreach (Pool pool in pools)
            {
                Queue<GameObject> objectPool = new Queue<GameObject>();

                for (int i = 0; i < pool.size; i++)
                {
                    GameObject obj = Instantiate(pool.prefab, this.transform);
                    obj.SetActive(false);
                    objectPool.Enqueue(obj);
                }

                poolDictionary.Add(pool.tag, objectPool);
            }
        }

        public GameObject SpawnFromPool(string tag, Vector3 position, Quaternion rotation)
        {
            if (!poolDictionary.ContainsKey(tag))
            {
                Debug.LogWarning($"Pool with tag '{tag}' doesn't exist!");
                return null;
            }

            GameObject objectToSpawn = poolDictionary[tag].Dequeue();

            objectToSpawn.SetActive(true);
            objectToSpawn.transform.position = position;
            objectToSpawn.transform.rotation = rotation;

            // Reset components implementing IPooledObject
            IPooledObject pooledObj = objectToSpawn.GetComponent<IPooledObject>();
            if (pooledObj != null)
            {
                pooledObj.OnObjectSpawn();
            }

            poolDictionary[tag].Enqueue(objectToSpawn);
            return objectToSpawn;
        }
    }

    public interface IPooledObject
    {
        void OnObjectSpawn();
    }


    // =========================================================================
    // 2. ENEMY TYPES AND GHOST AI / MOVEMENT COMPONENT
    // =========================================================================
    public enum EnemyType { Regular, Speedy, Tank }

    public class EnemyMovement : MonoBehaviour, IPooledObject
    {
        [Header("Entity Parameters")]
        public EnemyType enemyType;
        public int maxHp = 1;
        [HideInInspector] public int currentHp;

        [Header("Movement Settings")]
        public float baseVerticalSpeed = 2f;
        public float wobbleAmplitude = 0.5f;
        public float wobbleFrequency = 2f;

        private float _verticalSpeed;
        private float _spawnTime;
        private float _startX;
        private bool _isDying = false;

        [Header("Visual Elements")]
        [SerializeField] private Animator animator;
        [SerializeField] private SpriteRenderer spriteRenderer;

        public void OnObjectSpawn()
        {
            _isDying = false;
            currentHp = maxHp;
            _spawnTime = Time.time;
            _startX = transform.position.x;

            // Apply slight random variance to float speed & wobble shapes
            _verticalSpeed = baseVerticalSpeed * Random.Range(0.85f, 1.25f);
            
            if (animator != null) animator.Play("SpawnBounce");
        }

        private void Update()
        {
            if (_isDying) return;

            // 1. Float upwards
            transform.Translate(Vector3.up * _verticalSpeed * Time.deltaTime, Space.World);

            // 2. Horizontal sine-wave wiggle
            float elapsed = Time.time - _spawnTime;
            float currentWobble = Mathf.Sin(elapsed * wobbleFrequency) * wobbleAmplitude;
            transform.position = new Vector3(_startX + currentWobble, transform.position.y, transform.position.z);

            // 3. Screen bounds boundary check (Recycle back into pool if escaped)
            Vector3 viewportPos = Camera.main.WorldToViewportPoint(transform.position);
            if (viewportPos.y > 1.15f)
            {
                GameManager.Instance.OnGhostEscaped();
                gameObject.SetActive(false);
            }
        }

        public void TakeDamage(int damage, Vector3 tapPoint)
        {
            if (_isDying) return;

            currentHp -= damage;
            
            // Pop nice slime splashed burst
            GameObject splash = ObjectPooler.Instance.SpawnFromPool("SlimeSplashParticle", tapPoint, Quaternion.identity);

            if (currentHp <= 0)
            {
                Die();
            }
            else
            {
                // Play tiny hurt animation
                if (animator != null) animator.SetTrigger("Hit");
            }
        }

        private void Die()
        {
            _isDying = true;
            
            int baseRewardPoints = enemyType == EnemyType.Regular ? 10 : (enemyType == EnemyType.Speedy ? 20 : 50);
            ScoreComboManager.Instance.AddScore(baseRewardPoints);

            // Pop splat sound effect
            if (AudioManager.Instance != null) AudioManager.Instance.PlaySplashSound();

            if (animator != null)
            {
                animator.SetTrigger("Die");
                Invoke(nameof(Deactivate), 0.35f); // Let death puff play out
            }
            else
            {
                Deactivate();
            }
        }

        private void Deactivate()
        {
            gameObject.SetActive(false);
        }
    }


    // =========================================================================
    // 3. MOBILE INPUT & RAYCAST TAP DETECTOR
    // =========================================================================
    public class TapDetector : MonoBehaviour
    {
        public LayerMask ghostLayer;

        private void Update()
        {
            // Support both Mobile Touch inputs and Unity Editor Mouse Clicks
            if (Input.touchCount > 0)
            {
                Touch touch = Input.GetTouch(0);
                if (touch.phase == TouchPhase.Began)
                {
                    DetectTap(touch.position);
                }
            }
            else if (Input.GetMouseButtonDown(0))
            {
                DetectTap(Input.mousePosition);
            }
        }

        private void DetectTap(Vector3 screenPosition)
        {
            Vector3 worldPos = Camera.main.ScreenToWorldPoint(screenPosition);
            Vector2 touchPosWorld2D = new Vector2(worldPos.x, worldPos.y);

            // Emit precise 2D Raycast
            RaycastHit2D hit = Physics2D.Raycast(touchPosWorld2D, Vector2.zero, Mathf.Infinity, ghostLayer);

            if (hit.collider != null)
            {
                EnemyMovement ghost = hit.collider.GetComponent<EnemyMovement>();
                if (ghost != null)
                {
                    ghost.TakeDamage(1, worldPos);
                }
            }
            else
            {
                // Blank click miss, break combo
                ScoreComboManager.Instance.ResetCombo();
                if (AudioManager.Instance != null) AudioManager.Instance.PlayMissSound();
            }
        }
    }


    // =========================================================================
    // 4. SCORE & COMBO TIMING DECAY SYSTEM
    // =========================================================================
    public class ScoreComboManager : MonoBehaviour
    {
        public static ScoreComboManager Instance;

        public int currentScore = 0;
        public int comboCount = 0;
        public int comboMultiplier = 1;
        public float comboGauge = 1.0f;

        [Header("Combo Window Duration")]
        public float comboCooldownWindow = 2.5f;
        private float _lastKillTime;

        // Custom delegates for binding canvas text update events
        public UnityAction<int, int> OnScoreComboChanged;

        private void Awake()
        {
            Instance = this;
        }

        private void Start()
        {
            currentScore = 0;
            comboCount = 0;
            comboMultiplier = 1;
        }

        private void Update()
        {
            if (comboCount > 0)
            {
                // Linear decay of combo bar
                float deltaSec = Time.time - _lastKillTime;
                comboGauge = Mathf.Clamp01(1.0f - (deltaSec / comboCooldownWindow));

                if (comboGauge <= 0)
                {
                    ResetCombo();
                }
            }
        }

        public void AddScore(int basePoints)
        {
            comboCount++;
            _lastKillTime = Time.time;

            // Multiplier steps
            if (comboCount >= 20) comboMultiplier = 5;
            else if (comboCount >= 10) comboMultiplier = 3;
            else if (comboCount >= 5) comboMultiplier = 2;
            else comboMultiplier = 1;

            currentScore += basePoints * comboMultiplier;

            OnScoreComboChanged?.Invoke(currentScore, comboCount);
            if (AudioManager.Instance != null) AudioManager.Instance.PlayPopSound(comboMultiplier);
        }

        public void ResetCombo()
        {
            comboCount = 0;
            comboMultiplier = 1;
            comboGauge = 0f;
            OnScoreComboChanged?.Invoke(currentScore, comboCount);
        }
    }


    // =========================================================================
    // 5. ENEMY AUTOMATED SPAWNER MANAGER (DIFFICULTY STEPPING SYSTEM)
    // =========================================================================
    public class EnemySpawnManager : MonoBehaviour
    {
        [Header("Spawn Thresholds")]
        public float initialSpawnInterval = 1.8f;
        public float minSpawnInterval = 0.65f;
        public float difficultyDecreaseRate = 0.015f; // Decreases spawn tick window every second
        
        [Header("Map Boundaries")]
        public float leftBoundaryX = -2.2f;
        public float rightBoundaryX = 2.2f;
        public float spawnYOffset = -6.0f; // Spawns just below screen threshold

        private float _currentSpawnInterval;
        private float _timeSinceStart;
        private float _nextSpawnTimer;

        private void Start()
        {
            _currentSpawnInterval = initialSpawnInterval;
            _timeSinceStart = 0f;
            _nextSpawnTimer = Time.time + _currentSpawnInterval;
        }

        private void Update()
        {
            if (GameManager.Instance.IsGameOver) return;

            _timeSinceStart += Time.deltaTime;

            // Recalculate interval for progressive intensity
            _currentSpawnInterval = Mathf.Max(minSpawnInterval, initialSpawnInterval - (_timeSinceStart * difficultyDecreaseRate));

            if (Time.time >= _nextSpawnTimer)
            {
                _nextSpawnTimer = Time.time + _currentSpawnInterval;
                SpawnGhost();
            }
        }

        private void SpawnGhost()
        {
            // Randomized float offsets
            float randomX = Random.Range(leftBoundaryX, rightBoundaryX);
            Vector3 spawnPosition = new Vector3(randomX, spawnYOffset, 0f);

            // Pick Ghost tags based on game time elapsed
            string selectedPoolTag = "RegularGhost";
            float roll = Random.value;

            if (_timeSinceStart > 45f && roll < 0.22f)
            {
                selectedPoolTag = "TankGhost";
            }
            else if (_timeSinceStart > 20f && roll < 0.45f)
            {
                selectedPoolTag = roll < 0.28f ? "SpeedyGhost" : "TankGhost";
            }
            else if (_timeSinceStart > 10f && roll < 0.35f)
            {
                selectedPoolTag = "SpeedyGhost";
            }

            ObjectPooler.Instance.SpawnFromPool(selectedPoolTag, spawnPosition, Quaternion.identity);
        }
    }


    // =========================================================================
    // 6. MASTER GAME MANAGER SYSTEM & MONETIZATION SIMULATOR
    // =========================================================================
    public class GameManager : MonoBehaviour
    {
        public static GameManager Instance;

        public bool IsGameOver { get; private set; } = false;
        public int lives = 3;

        public UnityEvent OnGameOverStarted;
        public UnityEvent<int> OnLivesChanged;

        private void Awake()
        {
            Instance = this;
        }

        private void Start()
        {
            IsGameOver = false;
            lives = 3;
            OnLivesChanged?.Invoke(lives);
        }

        public void OnGhostEscaped()
        {
            if (IsGameOver) return;

            lives--;
            OnLivesChanged?.Invoke(lives);
            
            // Break combo
            ScoreComboManager.Instance.ResetCombo();

            if (lives <= 0)
            {
                TriggerGameOver();
            }
        }

        private void TriggerGameOver()
        {
            IsGameOver = true;
            OnGameOverStarted?.Invoke();
            DeactivateAllGhosts();

            if (AudioManager.Instance != null) AudioManager.Instance.PlayGameOverSound();
        }

        private void DeactivateAllGhosts()
        {
            EnemyMovement[] activeGhosts = FindObjectsOfType<EnemyMovement>();
            foreach (var ghost in activeGhosts)
            {
                if (ghost.gameObject.activeInHierarchy)
                {
                    ghost.gameObject.SetActive(false);
                }
            }
        }

        public void RestartGame()
        {
            UnityEngine.SceneManagement.SceneManager.LoadScene(UnityEngine.SceneManagement.SceneManager.GetActiveScene().name);
        }

        // --- Simulated Monetization Ad Connects ---
        public void WatchDoubleScoreAd()
        {
            // Simulate playing interstitial ad video (3-5s timer popup)
            Debug.Log("Simulated Rewarded Ad started for double score...");
            ScoreComboManager.Instance.currentScore *= 2;
            ScoreComboManager.Instance.ResetCombo();
            Debug.Log("Ad complete: Score Doubled!");
        }

        public void WatchReviveAd()
        {
            Debug.Log("Simulated Rewarded Ad started for reviving player...");
            IsGameOver = false;
            lives = 3;
            OnLivesChanged?.Invoke(lives);
            // Spawn Spawner scripts back on
            Debug.Log("Ad complete: Canlanıldı!");
        }
    }


    // =========================================================================
    // 7. PLACEHOLDER AUDIO ENGINE PROVIDER
    // =========================================================================
    public class AudioManager : MonoBehaviour
    {
        public static AudioManager Instance;

        public AudioSource audioSource;
        public AudioClip popClip;
        public AudioClip splashClip;
        public AudioClip missClip;
        public AudioClip gameOverClip;

        private void Awake()
        {
            Instance = this;
        }

        public void PlayPopSound(int combo)
        {
            if (audioSource != null && popClip != null)
            {
                // Pitch rises smoothly based on combo multiplication
                audioSource.pitch = 1.0f + (combo * 0.15f);
                audioSource.PlayOneShot(popClip, 0.7f);
            }
        }

        public void PlaySplashSound()
        {
            if (audioSource != null && splashClip != null)
            {
                audioSource.pitch = Random.Range(0.85f, 1.15f);
                audioSource.PlayOneShot(splashClip, 1.0f);
            }
        }

        public void PlayMissSound()
        {
            if (audioSource != null && missClip != null)
            {
                audioSource.pitch = 0.9f;
                audioSource.PlayOneShot(missClip, 0.5f);
            }
        }

        public void PlayGameOverSound()
        {
            if (audioSource != null && gameOverClip != null)
            {
                audioSource.pitch = 1.0f;
                audioSource.PlayOneShot(gameOverClip, 1.0f);
            }
        }
    }
}
